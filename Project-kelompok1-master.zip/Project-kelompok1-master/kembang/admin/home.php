<h2>Selamat Datang Administrator Kembang 7 Rupa</h2>
<pre><?php print_r($_SESSION); ?></pre>